# Nova AI 6.0 Hybrid Starter (HTML + Kotlin)

এই ZIP-এ মূল Nova AI Android প্রজেক্টের সঙ্গে একটি HTML/CSS/JavaScript WebView interface এবং Kotlin bridge যোগ করা হয়েছে।

## Included in this source
- HTML/CSS/JS Nova chat interface.
- Existing Gemini client (`LlmClient`) দিয়ে typed chat.
- Device-local Gemini key entry through the existing Store preferences.
- Native speech recognition entry point with Auto/Bangla/English language selection.
- Native text-to-speech using the existing Tts helper.
- Open installed apps by launcher label using existing DeviceActions.
- Accessibility service to read visible UI text and click a visible text label.
- Tap action requires an explicit JavaScript confirmation dialog before invoking Android Accessibility.

## Important limitations (not a finished all-features release)
- **Live screen recording / continuous frame streaming is NOT implemented yet.** The Share Screen control explains this instead of pretending it works.
- The current screen reader extracts accessible text; it does not visually understand screenshots or protected app surfaces.
- Tap-by-label can fail on custom-drawn controls, icon-only buttons, secure screens, or apps that hide accessibility nodes.
- Gemini image/vision analysis is not wired to screen frames in this starter.
- Speech recognition language detection depends on the phone's installed speech service. Auto mode may not identify every Bangla-English mixed utterance correctly.
- No APK was built or runtime-tested in this environment. Build and test with Android Studio / Gradle before installing.

## Build
1. Open this folder in Android Studio.
2. Sync Gradle and build the `app` module.
3. Install the debug APK on your own test phone.
4. Add your Gemini API key in Nova's AI Provider panel.
5. Open Android Settings → Accessibility → Nova AI and enable it only if you want screen text reading and tap-by-label.
6. Test the microphone permission when using Voice.

## Security
- Never publish an APK containing your personal API key. This starter stores the key in the app's existing SharedPreferences on the device; this is convenient for testing but is not a production-grade secret vault.
- Accessibility access is powerful. Enable it only for your own trusted build and keep user confirmation before taps.
- Android screen capture must use the operating system's MediaProjection consent UI. Do not try to capture the screen secretly.
- Before public distribution, move API requests behind a secure backend, add proper key protection, privacy disclosures, and robust error handling.


## Microphone privacy behavior (6.0.1 update)
- Microphone is **not** started on app launch.
- No wake-word / always-listening service is started by the HTML hybrid launcher.
- Voice recognition starts only after the user taps the Voice button.
- One utterance is recognized, then SpeechRecognizer is stopped, cancelled and destroyed.
- Microphone recognition is also stopped when the activity is paused, stopped, or destroyed.
- Screen sharing does not start microphone capture.
