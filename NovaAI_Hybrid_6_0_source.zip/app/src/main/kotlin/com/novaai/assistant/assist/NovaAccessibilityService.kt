package com.novaai.assistant.assist

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class NovaAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onServiceConnected() { super.onServiceConnected(); current = this }
    override fun onDestroy() { if (current === this) current = null; super.onDestroy() }

    private fun gather(n: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int = 0) {
        if (n == null || depth > 22 || out.size > 150) return
        n.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(out::add)
        n.contentDescription?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(out::add)
        for (i in 0 until n.childCount) gather(n.getChild(i), out, depth + 1)
    }
    fun readVisibleText(): String {
        val root = rootInActiveWindow ?: return "Active screen is unavailable. Enable Nova's Accessibility service."
        val out = mutableListOf<String>(); gather(root, out)
        return out.distinct().take(100).joinToString("\n").ifBlank { "No readable text on this screen." }
    }
    fun tapLabel(label: String): String {
        val root = rootInActiveWindow ?: return "Screen is unavailable"
        val matches = root.findAccessibilityNodeInfosByText(label)
        matches?.forEach { found ->
            var n: AccessibilityNodeInfo? = found
            repeat(8) {
                if (n != null && n.isClickable && n.isEnabled && n.performAction(AccessibilityNodeInfo.ACTION_CLICK))
                    return "Tapped: $label"
                n = n?.parent
            }
        }
        return "Couldn't tap '$label'. Try the exact visible button text."
    }
    companion object {
        @Volatile private var current: NovaAccessibilityService? = null
        fun readScreen() = current?.readVisibleText() ?: "Enable Nova AI under Android Settings → Accessibility."
        fun tapText(label: String) = current?.tapLabel(label) ?: "Enable Nova AI under Android Settings → Accessibility."
    }
}
