package com.novaai.assistant.hybrid

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.novaai.assistant.ai.LlmClient
import com.novaai.assistant.assist.NovaAccessibilityService
import com.novaai.assistant.control.DeviceActions
import com.novaai.assistant.data.Store
import com.novaai.assistant.voice.Tts
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject

class NovaWebActivity : Activity() {
    private lateinit var web: WebView
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = false
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                // Keep the JavaScript bridge limited to the bundled local UI.
                return url == null || !url.startsWith("file:///android_asset/")
            }
        }
        web.addJavascriptInterface(Bridge(), "Nova")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun saveGeminiKey(key: String) {
            if (key.length !in 20..300) { toast("API key format looks invalid"); return }
            Store.put("k_gemini", key.trim())
            Store.put("provider", "gemini")
            toast("Gemini key saved on this device")
        }

        @JavascriptInterface fun ask(prompt: String, callback: String) {
            if (prompt.isBlank() || prompt.length > 8000) { js(callback, "Please enter a shorter message"); return }
            scope.launch {
                val answer = runCatching { LlmClient.chat(listOf(true to prompt)) }
                    .getOrElse { "AI error: ${it.message ?: "Could not get a response"}" }
                js(callback, answer)
            }
        }

        @JavascriptInterface fun speak(text: String) { runOnUiThread { Tts.speak(this@NovaWebActivity, text.take(1500)) } }

        @JavascriptInterface fun openApp(name: String) {
            runOnUiThread {
                val ok = DeviceActions.openAppByName(this@NovaWebActivity, name)
                if (!ok) toast("Couldn't find app: $name")
            }
        }

        @JavascriptInterface fun enableAccessibility() {
            runOnUiThread {
                startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
                toast("Find Nova AI and enable its screen-control service")
            }
        }

        @JavascriptInterface fun readScreen(callback: String) {
            val text = NovaAccessibilityService.readScreen()
            js(callback, text)
        }

        @JavascriptInterface fun tapText(label: String, callback: String) {
            val result = NovaAccessibilityService.tapText(label)
            js(callback, result)
        }

        @JavascriptInterface fun tapText(label: String, callback: String) {
            val result = NovaAccessibilityService.tapText(label)
            js(callback, result)
        }

        @JavascriptInterface fun startScreenShare() {
            runOnUiThread {
                toast("Screen sharing needs Android's separate screen-capture consent flow. This starter build does not yet stream frames.")
            }
        }

        @JavascriptInterface fun listen(onHeard: String, onError: String, language: String) {
            runOnUiThread {
                if (ContextCompat.checkSelfPermission(this@NovaWebActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@NovaWebActivity, arrayOf(Manifest.permission.RECORD_AUDIO), 401)
                    js(onError, "Allow microphone permission, then tap Voice again")
                    return@runOnUiThread
                }
                if (!SpeechRecognizer.isRecognitionAvailable(this@NovaWebActivity)) {
                    js(onError, "Speech recognition is not available on this phone"); return@runOnUiThread
                }
                recognizer?.destroy()
                recognizer = SpeechRecognizer.createSpeechRecognizer(this@NovaWebActivity)
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                if (!language.equals("auto", ignoreCase = true)) {
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (language == "en") "en-US" else "bn-BD")
                }
                recognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) {
                        releaseMicrophone()
                        js(onError, "Voice recognition error ($error)")
                    }
                    override fun onResults(results: Bundle?) {
                        val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        releaseMicrophone()
                        if (spoken.isNullOrBlank()) js(onError, "কথা বুঝতে পারিনি") else js(onHeard, spoken)
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                recognizer?.startListening(intent)
            }
        }
    }

    // The microphone is acquired only after the user taps the Voice button.
    // One utterance is processed, then SpeechRecognizer is destroyed.
    private fun releaseMicrophone() {
        runOnUiThread {
            runCatching { recognizer?.stopListening() }
            runCatching { recognizer?.cancel() }
            runCatching { recognizer?.destroy() }
            recognizer = null
        }
    }

    override fun onPause() {
        releaseMicrophone()
        super.onPause()
    }

    override fun onStop() {
        releaseMicrophone()
        super.onStop()
    }

    private fun js(callback: String, value: String) {
        val safeName = callback.filter { it.isLetterOrDigit() || it == '_' }
        if (safeName.isBlank()) return
        val encoded = JSONObject.quote(value)
        runOnUiThread { web.evaluateJavascript("window.$safeName && window.$safeName($encoded)", null) }
    }
    private fun toast(message: String) = runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }

    override fun onDestroy() {
        releaseMicrophone()
        web.removeJavascriptInterface("Nova")
        web.destroy()
        super.onDestroy()
    }
}
