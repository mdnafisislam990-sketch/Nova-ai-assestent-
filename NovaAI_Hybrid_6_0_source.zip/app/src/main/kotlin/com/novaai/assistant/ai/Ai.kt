package com.novaai.assistant.ai

import android.content.Context
import com.novaai.assistant.assist.IntentRouter
import com.novaai.assistant.control.DeviceActions
import com.novaai.assistant.data.Repo
import com.novaai.assistant.data.Store
import com.novaai.assistant.voice.Tts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class NoKeyException : Exception("NO_KEY")

object LlmClient {
    private const val SYSTEM =
        "You are Nova, a bilingual Bangla-English phone assistant. Understand Bangla script, English, " +
            "Banglish (Bangla written in Latin letters), mixed-language sentences, informal wording, " +
            "common spelling mistakes and speech-to-text errors. Infer intent from context without " +
            "demanding perfect wording. Reply in the user's language and style. Keep voice replies " +
            "natural and concise. Never claim you tapped, opened, saw or changed something unless the " +
            "Android app confirms it. For sensitive or irreversible actions, ask for confirmation."

    fun provider(): String? = when {
        Store.str("k_gemini").isNotBlank() -> "gemini"
        Store.str("k_groq").isNotBlank() -> "groq"
        Store.str("k_openai").isNotBlank() -> "openai"
        else -> null
    }

    private fun model(p: String): String = Store.str("m_$p").ifBlank {
        when (p) {
            "gemini" -> "gemini-flash-latest"
            "groq" -> "llama-3.3-70b-versatile"
            else -> "gpt-4o-mini"
        }
    }

    /** history: (fromUser, text) pairs, newest last. */
    suspend fun chat(history: List<Pair<Boolean, String>>): String = withContext(Dispatchers.IO) {
        val p = provider() ?: throw NoKeyException()
        val key = Store.str("k_$p").trim()
        val mem = Store.str("memory")
        val sys = SYSTEM + if (mem.isBlank()) "" else "\nWhat you know about the user: $mem"
        val msgs = history.dropWhile { !it.first }

        if (p == "gemini") {
            val contents = JSONArray()
            msgs.forEach { (u, t) ->
                contents.put(
                    JSONObject().put("role", if (u) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", t)))
                )
            }
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                .put("contents", contents).toString()
            val res = post(
                "https://generativelanguage.googleapis.com/v1beta/models/${model(p)}:generateContent",
                mapOf("x-goog-api-key" to key), body
            )
            val parts = JSONObject(res).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            buildString { for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text")) }.trim()
        } else {
            val arr = JSONArray().put(JSONObject().put("role", "system").put("content", sys))
            msgs.forEach { (u, t) -> arr.put(JSONObject().put("role", if (u) "user" else "assistant").put("content", t)) }
            val url = if (p == "groq") "https://api.groq.com/openai/v1/chat/completions"
            else "https://api.openai.com/v1/chat/completions"
            val body = JSONObject().put("model", model(p)).put("messages", arr).toString()
            val res = post(url, mapOf("Authorization" to "Bearer $key"), body)
            JSONObject(res).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        }
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }.getOrDefault("HTTP $code")
                throw IOException(msg)
            }
            return text
        } finally {
            c.disconnect()
        }
    }

    fun imageUrl(prompt: String) =
        "https://image.pollinations.ai/prompt/" + URLEncoder.encode(prompt, "UTF-8") + "?width=768&height=768&nologo=true"
}

data class Reply(val text: String, val close: Boolean = false)

/** One path for typed chat, in-app voice, the floating orb and wake word. */
object ChatEngine {
    suspend fun send(ctx: Context, text: String, speak: Boolean = false): Reply {
        val app = ctx.applicationContext
        Repo.addUser(text)
        Repo.busy.value = true
        var ok = true
        var close = false
        val out: String = try {
            val r = IntentRouter.route(app, text)
            close = r.close
            when {
                r.searchQuery != null -> {
                    DeviceActions.webSearch(app, r.searchQuery)
                    try {
                        LlmClient.chat(listOf(true to "Answer briefly in 2 short sentences, in my language: ${r.searchQuery}"))
                    } catch (e: Exception) {
                        "Opening Google results for ${r.searchQuery}"
                    }
                }
                r.handled -> r.reply
                else -> {
                    val hist = Repo.messages.value.filter { it.imageUrl == null }.takeLast(12).map { it.fromUser to it.text }
                    LlmClient.chat(hist)
                }
            }
        } catch (e: NoKeyException) {
            ok = false
            "Add an AI key first: Settings → Connections. Free Gemini key: aistudio.google.com/apikey"
        } catch (e: Exception) {
            ok = false
            "Couldn't get an answer: ${e.message ?: "unknown error"}"
        }
        Repo.addAssistant(out)
        Repo.busy.value = false
        if (speak && ok) Tts.speak(app, out)
        return Reply(out, close)
    }

    fun image(prompt: String) {
        Repo.addUser("🖼️ $prompt")
        Repo.addAssistant("", LlmClient.imageUrl(prompt))
    }
}
