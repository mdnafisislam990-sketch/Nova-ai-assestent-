package com.novaai.assistant.assist

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.novaai.assistant.R
import com.novaai.assistant.utils.Perms
import com.novaai.assistant.voice.Stt
import com.novaai.assistant.widget.OrbOverlayService

/** "Hey Nova" listener. Simple and battery-hungry: it keeps the recognizer running while enabled. */
class WakeWordService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var stt: Stt? = null
    private var running = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (!Perms.has(this, Manifest.permission.RECORD_AUDIO)) { stopSelf(); return START_NOT_STICKY }
        if (!running) { running = true; loop() }
        return START_STICKY
    }

    private fun startAsForeground() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("nova_wake", "Hey Nova", NotificationManager.IMPORTANCE_MIN))
        val n = NotificationCompat.Builder(this, "nova_wake")
            .setSmallIcon(R.drawable.ic_stat_nova).setContentTitle("Nova")
            .setContentText("Listening for \"Hey Nova\"").setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 30) {
            try { startForeground(2003, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) } catch (e: Exception) { stopSelf() }
        } else startForeground(2003, n)
    }

    private fun isWake(t: String): Boolean {
        val s = t.lowercase()
        return listOf("hey nova", "hi nova", "ok nova", "nova", "হেই নোভা", "হে নোভা", "হ্যালো নোভা", "নোভা").any { s.contains(it) }
    }

    private fun loop() {
        if (!running) return
        val s = stt ?: Stt(this).also { stt = it }
        s.start(
            onText = { t ->
                if (isWake(t)) {
                    s.stop()
                    OrbOverlayService.start(this, listen = true)
                    handler.postDelayed({ loop() }, 20000)
                } else handler.postDelayed({ loop() }, 400)
            },
            onFail = { handler.postDelayed({ loop() }, 1200) }
        )
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        stt?.stop()
        super.onDestroy()
    }

    companion object {
        fun start(ctx: Context) { runCatching { ctx.startForegroundService(Intent(ctx, WakeWordService::class.java)) } }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, WakeWordService::class.java)) }
    }
}
